function out = x_grating(X,a)
out = tand(a).*X;
